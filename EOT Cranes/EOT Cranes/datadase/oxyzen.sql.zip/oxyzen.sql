-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 31, 2021 at 06:16 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `eot`
--

-- --------------------------------------------------------

--
-- Table structure for table `bill_details`
--

CREATE TABLE `bill_details` (
  `bill_details_id` int(11) NOT NULL auto_increment,
  `bill_master_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `rate` double NOT NULL,
  `discount` double NOT NULL,
  PRIMARY KEY  (`bill_details_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `bill_details`
--


-- --------------------------------------------------------

--
-- Table structure for table `bill_master`
--

CREATE TABLE `bill_master` (
  `bill_master_id` int(11) NOT NULL auto_increment,
  `bill_date` date NOT NULL,
  `customer_id` int(11) NOT NULL,
  `other_charges` double NOT NULL,
  PRIMARY KEY  (`bill_master_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `bill_master`
--


-- --------------------------------------------------------

--
-- Table structure for table `customer_details`
--

CREATE TABLE `customer_details` (
  `customer_id` int(11) NOT NULL auto_increment,
  `customer_name` varchar(50) NOT NULL,
  `customer_address` varchar(200) NOT NULL,
  `customer_city` varchar(50) NOT NULL,
  `contact_no` bigint(12) NOT NULL,
  `email_id` varchar(100) NOT NULL,
  `customer_code` varchar(50) NOT NULL,
  PRIMARY KEY  (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `customer_details`
--


-- --------------------------------------------------------

--
-- Table structure for table `customer_order_details`
--

CREATE TABLE `customer_order_details` (
  `customer_order_details_id` int(11) NOT NULL auto_increment,
  `customer_order_master_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `cust_order_status` varchar(50) NOT NULL,
  PRIMARY KEY  (`customer_order_details_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `customer_order_details`
--


-- --------------------------------------------------------

--
-- Table structure for table `customer_order_master`
--

CREATE TABLE `customer_order_master` (
  `customer_order_master_id` int(11) NOT NULL auto_increment,
  `date` date NOT NULL,
  `customer_id` int(11) NOT NULL,
  PRIMARY KEY  (`customer_order_master_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `customer_order_master`
--


-- --------------------------------------------------------

--
-- Table structure for table `customer_receipts`
--

CREATE TABLE `customer_receipts` (
  `customer_receipts_id` int(11) NOT NULL auto_increment,
  `customer_id` int(11) NOT NULL,
  `amount` double NOT NULL,
  `narration` varchar(500) NOT NULL,
  `Date` date NOT NULL,
  PRIMARY KEY  (`customer_receipts_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `customer_receipts`
--


-- --------------------------------------------------------

--
-- Table structure for table `expenditure`
--

CREATE TABLE `expenditure` (
  `expenditure_id` int(11) NOT NULL auto_increment,
  `expenditure_name` varchar(200) NOT NULL,
  `description` varchar(500) NOT NULL,
  `total_amount` double NOT NULL,
  `given_to` varchar(100) NOT NULL,
  `voucher_no` varchar(50) NOT NULL,
  `given_date` date NOT NULL,
  PRIMARY KEY  (`expenditure_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `expenditure`
--


-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `hint_q` varchar(100) NOT NULL,
  `hint_a` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`username`, `password`, `type`, `hint_q`, `hint_a`, `status`) VALUES
('admin', '123', 'admin', 'who_r_u', 'admin', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `production`
--

CREATE TABLE `production` (
  `production_id` int(11) NOT NULL auto_increment,
  `product_id` int(11) NOT NULL,
  `total_production` double NOT NULL,
  `description` varchar(500) NOT NULL,
  `production_date` date NOT NULL,
  PRIMARY KEY  (`production_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `production`
--


-- --------------------------------------------------------

--
-- Table structure for table `product_category`
--

CREATE TABLE `product_category` (
  `product_category_id` int(11) NOT NULL auto_increment,
  `product_category_name` varchar(100) NOT NULL,
  PRIMARY KEY  (`product_category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `product_category`
--


-- --------------------------------------------------------

--
-- Table structure for table `product_details`
--

CREATE TABLE `product_details` (
  `product_id` int(11) NOT NULL auto_increment,
  `product_category_id` int(11) NOT NULL,
  `product_name` varchar(50) NOT NULL,
  `product_size` varchar(100) NOT NULL,
  `product_type` varchar(100) NOT NULL,
  `product_description` varchar(200) NOT NULL,
  `product_image` varchar(500) NOT NULL,
  `product_price` double NOT NULL,
  PRIMARY KEY  (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `product_details`
--


-- --------------------------------------------------------

--
-- Table structure for table `raw_material_details`
--

CREATE TABLE `raw_material_details` (
  `raw_material_id` int(11) NOT NULL auto_increment,
  `raw_material_name` varchar(100) NOT NULL,
  `raw_material_description` varchar(500) NOT NULL,
  PRIMARY KEY  (`raw_material_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `raw_material_details`
--


-- --------------------------------------------------------

--
-- Table structure for table `raw_material_purchase`
--

CREATE TABLE `raw_material_purchase` (
  `raw_material_purchase_id` int(11) NOT NULL auto_increment,
  `vendor_id` int(11) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY  (`raw_material_purchase_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `raw_material_purchase`
--


-- --------------------------------------------------------

--
-- Table structure for table `raw_material_purchase_details`
--

CREATE TABLE `raw_material_purchase_details` (
  `raw_material_purchase_details_id` int(11) NOT NULL auto_increment,
  `raw_material_purchase_id` int(11) NOT NULL,
  `raw_material_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `rate` double NOT NULL,
  `discount` double NOT NULL,
  PRIMARY KEY  (`raw_material_purchase_details_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `raw_material_purchase_details`
--


-- --------------------------------------------------------

--
-- Table structure for table `stock_details`
--

CREATE TABLE `stock_details` (
  `stock_id` int(11) NOT NULL auto_increment,
  `product_id` int(11) NOT NULL,
  `stock` int(11) NOT NULL,
  PRIMARY KEY  (`stock_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `stock_details`
--


-- --------------------------------------------------------

--
-- Table structure for table `vendor_details`
--

CREATE TABLE `vendor_details` (
  `vendor_id` int(11) NOT NULL auto_increment,
  `vendor_name` varchar(50) NOT NULL,
  `vendor_address` varchar(200) NOT NULL,
  `vendor_city` varchar(20) NOT NULL,
  `contact_no` varchar(12) NOT NULL,
  `email_id` varchar(50) NOT NULL,
  `vendor_code` varchar(50) NOT NULL,
  `gst_no` varchar(100) NOT NULL,
  PRIMARY KEY  (`vendor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `vendor_details`
--


-- --------------------------------------------------------

--
-- Table structure for table `vendor_payment`
--

CREATE TABLE `vendor_payment` (
  `vendor_payment_id` int(11) NOT NULL auto_increment,
  `vendor_id` int(11) NOT NULL,
  `amount` double NOT NULL,
  `narration` varchar(500) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY  (`vendor_payment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `vendor_payment`
--

